let rectButtonX = 50;
let rectButtonY = 50;
let rectButtonWidth = 250;
let rectButtonHeight = 250;
let rectButtonColor;

let ellipseButtonX = 350;
let ellipseButtonY = 270;
let ellipseButtonWidth = 50;
let ellipseButtonHeight = 50;
let ellipseButtonColor;

let keyButtonX = 325;
let keyButtonY = 50;
let keyButtonWidth = 50;
let keyButtonHeight = 100;


function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255); 
  rectButtonColor = color(255); 
  ellipseButtonColor = color(0); 
}

function draw() {
  background(180,180,200);
  
  rect(keyButtonX, keyButtonY, keyButtonWidth, keyButtonHeight);
  
  if (mouseX > keyButtonX && mouseX < keyButtonX + keyButtonWidth && 
      mouseY > keyButtonY && mouseY < keyButtonY + keyButtonHeight && 
      keyIsPressed && key === 'a') {
    fill(90, 140, 100);
  } else {
    fill(100);
  }
  
  rect(keyButtonX, keyButtonY, keyButtonWidth, keyButtonHeight);
  
  fill(rectButtonColor);
  rect(rectButtonX, rectButtonY, rectButtonWidth, rectButtonHeight);
  
  fill(ellipseButtonColor);
  ellipse(ellipseButtonX, ellipseButtonY, ellipseButtonWidth, ellipseButtonHeight);
}

function mouseClicked() {
  if (mouseX > rectButtonX && mouseX < rectButtonX + rectButtonWidth &&
      mouseY > rectButtonY && mouseY < rectButtonY + rectButtonHeight) {
    rectButtonColor = color(100,150,200);
  }
  
  let distanceToEllipseCenter = dist(mouseX, mouseY, ellipseButtonX + ellipseButtonWidth/2, ellipseButtonY + ellipseButtonHeight/2);
  if (distanceToEllipseCenter< ellipseButtonWidth) {
    ellipseButtonColor = color(200,150,100);
  }
}

function mousePressed() {
  if (mouseX > rectButtonX && mouseX < rectButtonX + rectButtonWidth &&
      mouseY > rectButtonY && mouseY < rectButtonY + rectButtonHeight) {
    rectButtonColor = color(100,150,200);
  }
  
  let distanceToEllipseCenter = dist(mouseX, mouseY, ellipseButtonX + ellipseButtonWidth/2, ellipseButtonY + ellipseButtonHeight/2);
  if (distanceToEllipseCenter < ellipseButtonWidth) {
    ellipseButtonColor = color(200,150,100);
  }
}
