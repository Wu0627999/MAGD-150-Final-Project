
var ping;
var capture;
var sine;
var freq = 500;
var radius = 30;
var speed = 1;
var direction = 1;

function preload() {
	ping = loadSound("Ping.wav");
}

function setup() {
	createCanvas(800, 400);

	ellipseMode(RADIUS);
	x = 600;

	capture = createCapture();
	capture.hide();

	sine = new p5.SinOsc();
	sine.start();
}


function draw() {




	var hertz = map(mouseX, 0, 400, 20.0, 440.0);

	sine.freq(hertz);

	background(200);

	x += speed * direction;

	if ((x < 0+ radius) || (x > 800 - radius)) {

		direction = -direction;
		ping.play();

	}

	if (direction == 1) {
		fill(0);
		ellipse(x, 370, radius, radius);
	} else {
		fill(0);
		ellipse(x, 370, radius, radius);

		var hertz= map(mouseX,0,400,20.0,40.0);
		stroke(204);
}
	for (var z = 400; z < 800; z++) {

		var angle = map(z, 0, 400, 400, TWO_PI * hertz);

		var sinValue = sin(angle) * 120;

		stroke(50);
		line(z, -100, z, 200+ sinValue);
		
	}

	var aspectRatio = capture.height/capture.width;
	var h = (width/2) * aspectRatio;
	image(capture, 0, 0, (width/2), h);
	filter(INVERT);

}
