

function setup() {

  createCanvas(600, 400)
  angleMode(DEGREES);
}

function draw() {

  background(200,220,255);
 
  
   for (var x = 30; x < width + 10; x +=70) {
    cloud(x,45);
     
     fill(70,200,120);
     noStroke();
     rect(0,300,600,100);
     triangle(50,280,30,300,70,300);
     triangle(120,260,100,300,140,300);
     triangle(200,270,190,300,210,300);
     triangle(250,260,240,300,260,300);
     triangle(320,260,305,300,335,300);
     triangle(400,270,390,300,410,300);
     triangle(500,265,490,300,510,300);
        
  
}

function cloud(x, y) {

  push();

  translate(x, y);
  scale(1);
  rotate(TWO_PI);

  noStroke();
  fill(255);
  ellipse(x, y, 80, 60);
  ellipse(x + 30, y + 20, 60, 50);
  ellipse(x - 30, y + 20, 60, 50);
  pop(); 
  

   print(cloud);
   
 }
  

}