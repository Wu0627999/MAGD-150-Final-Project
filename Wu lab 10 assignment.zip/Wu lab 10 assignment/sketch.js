let vid;

function setup() {

  noCanvas();

  vid = createVideo(
    ['assets/winter.mp4', 'assets/winter.ogv', 'assets/winter.webm'],
    vidLoad
  );

  vid.size(600, 400);
}

// This function is called when the video loads
function vidLoad() {
  vid.loop();
  vid.showControls();
  vid.volume(2);
  vid.speed(0.3);
  vid.play();

}

