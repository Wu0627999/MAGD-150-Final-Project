let circleX = 200;
let circleY = 200;
let circleSize = 50;
let circleColor = [255, 0, 255];
let bgColor = [255,255,255];
let textString = 'Please click';

function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255);
}

function draw() {
  background(bgColor);
  fill(circleColor);
  ellipse(circleX, circleY, circleSize);
  textSize(20);
  textAlign(CENTER);
  text(textString, 200, 300);
}

function mouseClicked() {
  if (dist(mouseX, mouseY, circleX, circleY) < circleSize/2) {
    circleColor = [255, 0, 0];
    textString = 'You clicked the circle';
  } else {
    circleColor = [255, 0, 255];
    textString = 'You didnt click the circle';
  }
}

function keyPressed() {
  if (key === ' ') {
    bgColor = [0, 0, 0];
    circleSize = 100;
    textString = 'You pressed the space bar';
  } else if (key === 's') {
    bgColor = [255, 255, 255];
    circleSize = 50;
    circleColor = [255, 0, 255];
    textString = 'You pressed the S key!';
  }
}

function mouseMoved() {
  for (let i = 0; i < 10; i++) {
    fill(random(255), random(255), random(255));
    ellipse(random(width), random(height), 20);
  }
}
