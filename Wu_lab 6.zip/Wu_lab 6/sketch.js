
var num = 60;

var x = [];

var y = [];
let a=60;
let b=50;

function setup() {

  createCanvas(400,400);

  noStroke();

  for (var i = 0; i < num; i++) {

    x[i] = 0;

    y[i] = 0;

  }

}

function draw() {

  background(150,200,240);
  
  a+=0.5
  noStroke();
  fill(255);
  ellipse(a, b, 80, 60);
  ellipse(a + 30, b + 20, 60, 50);
  ellipse(a - 30, b + 20, 60, 50);
  

  

  for (var i = num-1; i > 0; i--) {

    x[i] = x[i-1];

    y[i] = y[i-1];
  }

  x[0] = mouseX; 

  y[0] = mouseY; 

   fill(255,170,100);
  ellipse(x[i],y[i],66,66);
fill(255,255,120);
    ellipse(x[i], y[i], 50, 50);
  
  print(x.length);
}